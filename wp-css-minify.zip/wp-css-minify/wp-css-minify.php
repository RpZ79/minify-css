<?php
/**
 * Plugin Name: WP Minify CSS
 * Plugin URI: 
 * Description: Minifying your CSS to faster your site and increase its performance..
 * Version: 1.0.0
 * Author: Roopasree
 * Author URI:
 * Text Domain: minify-css
 *
 * WC requires at least: 5.0
 * WC tested up to: 7.7
*/

if(!defined('WPINC')) {	
	die; 
}

// Define plugin version for future releases
if (!defined('WPMCS_PLUGIN_VERSION')) {
    define('WPMCS_PLUGIN_VERSION', 'wpmcs_plugin_version');
}
if (!defined('WPMCS_PLUGIN_VERSION_NUM')) {
    define('WPMCS_PLUGIN_VERSION_NUM', '1.0.0');
}
update_option(WPMCS_PLUGIN_VERSION, WPMCS_PLUGIN_VERSION_NUM);


// Activate the plugin
function wpmcs_activate_plugin() {

}
register_activation_hook( __FILE__, 'wpmcs_activate_plugin' );

/** Remove filters/functions on plugin deactivation **/
function wpmcs_deactivate_plugin() {
	delete_option( 'wpmcs_plugin_version' );
}
register_deactivation_hook( __FILE__, 'wpmcs_deactivate_plugin' );


# run during activation
register_activation_hook(__FILE__, 'wpc_plugin_activate');

/** create database **/
function wpc_plugin_activate() {		
	global $wpdb;
	if(is_null($wpdb)) { return false; }
	$charset_collate = $wpdb->get_charset_collate();
	$sqla_table_name = $wpdb->prefix . 'wpc_cache';
		
	# create cache table	
	$sqla = "CREATE TABLE {$sqla_table_name} (
		id bigint(20) unsigned NOT NULL auto_increment ,
		uid varchar(64) NOT NULL,
		date bigint(10) unsigned NOT NULL, 
		type varchar(3) NOT NULL, 
		content mediumtext NOT NULL, 
		meta mediumtext NOT NULL,
		PRIMARY KEY  (id),
		UNIQUE KEY uid (uid), 
		KEY date (date), KEY type (type) 
		) $charset_collate;";

	# run sql
	# https://developer.wordpress.org/reference/functions/dbdelta/
	require_once( ABSPATH . 'wp-admin/includes/upgrade.php' );
	dbDelta( $sqla );
	
	# test if at least one table exists
	if (!$wpdb->get_var($wpdb->prepare("SHOW TABLES LIKE %s", $sqla_table_name)) === $sqla_table_name) {
		
	} else {
	}

}


//************* Core minifying functions. ************

# Include lib files.
$path = plugin_dir_path( __FILE__ );
require_once ("$path/lib/raisermin/minify.php");
require_once ("$path/lib/SimpleHtmlDom/simple_html_dom.php");

require_once("$path/lib/minify/src/Minify.php");
require_once("$path/lib/minify/src/CSS.php");
require_once("$path/lib/minify/src/JS.php");
require_once("$path/lib/minify/src/Exception.php");
require_once("$path/lib/path-converter/src/ConverterInterface.php");
require_once("$path/lib/path-converter/src/Converter.php");
require_once("$path/lib/path-converter/src/NoConverter.php");

/** Minify function **/
function wpmcs_minify() {
    ob_start('wpmcs_minify_css');
}
add_action('get_header', 'wpmcs_minify');

/**  main minifying function. **/
function wpmcs_minify_css($html) {
	$wpmcs_plugin_version = get_option('wpmcs_plugin_version');
	
	$html_object = str_get_html($html, false, true, 'UTF-8', false, PHP_EOL, ' ');
	if (!is_object($html_object)) {
		return $html . '<!-- simplehtmldom failed to process the html -->';
	} else {
		$html_src = $html;
		$html = $html_object;
	}

	# defaults
	$allcss = array();

	# only error possible for now
	$wpc_error = PHP_EOL . '<!-- ['.date('r').'] wp minfy has no write access for CSS / JS cache files under '. wpc_get_cache_location()['ch_url'] . ' -->'. PHP_EOL;
	
						
	# exclude styles and link tags inside scripts, no scripts or html comments
	$excl = array();
	foreach($html->find('script link[rel=stylesheet], script style, noscript style, noscript link[rel=stylesheet], comment') as $element) {
		$excl[] = $element->outertext;
	}	
	# collect all styles, but filter out if excluded
	foreach($html->find('link[rel=stylesheet], style') as $element) {
		if(!in_array($element->outertext, $excl)) {
			$allcss[] = $element;
		}
	}
	# START CSS LOOP
	foreach($allcss as $k=>$tag) {
		if($tag->tag == 'link' && isset($tag->href)) {
			# filter url
			$href = wpc_normalize_url($tag->href);
			
			# download or fetch from transient, minified
			$css = wpc_get_css_from_file($tag);
			
			
			if($css !== false && is_array($css)) {
				# error
				if(isset($css['error'])) {
					$tag->outertext = '/* Error on '.$href.' : '.$css['error'].' */'. PHP_EOL . $tag->outertext;
					unset($allcss[$k]);
					continue;
				}
				$css_code = $css['code'];
				$css_code = '/* '.$href.' */'. PHP_EOL . $css_code;
					
				# generate url
				$ind_css_url = wpc_generate_min_url($href, $css['tkey'], 'css', $css_code);
				if($ind_css_url === false) { 
					return $html_src . $wpc_error;
				}
				$tag->href = $ind_css_url;
				unset($allcss[$k]);
			}
		}
		if($tag->tag == 'style' && !isset($tag->href)) {
			# default
			$css = $tag->innertext;
			$css = wpc_minify_css_string($css); 
			
			# handle import rules
			$css = wpc_replace_css_imports($css);
		}

	}

	return $html;

}

/**  minify css string with PHP Minify **/
function wpc_minify_css_string($css) {
	
	# return early if empty
	if(empty($css) || $css == false) { return $css; }
	
	# minify	
	$minifier = new MatthiasMullie\Minify\CSS($css);
	$minifier->setMaxImportSize(10); # embed assets up to 10 Kb (default 5Kb) - processes gif, png, jpg, jpeg, svg & woff
	$min = $minifier->minify();
		
	# return
	if($min != false) { 
		return $min; 
	}
	
	# fallback
	return $css;
}


/** functions, get full url **/
function wpc_normalize_url($href, $purl=null) {
	$wpc_urls = array('wp_site_url'=>trailingslashit(site_url()), 'wp_domain'=>wpc_get_domain());	

	# preserve empty source handles.
	$href = trim($href); 
	if(empty($href)) { return false; }      

	# some fixes.
	$href = str_replace(array('&#038;', '&amp;'), '&', $href);
	
	# external url.
	if(!is_null($purl) && !empty($purl)) {
		$parse = parse_url($purl);
	} else {

		# local url.
		$parse = parse_url($wpc_urls['wp_site_url']);
	}
	
	# domain info.
	$scheme = $parse['scheme'];
	$host = $parse['host'];
	$path = $parse['path'];
	
	# relative to full urls
	if (substr($href, 0, 2) === "//") {
		$href = $scheme.':'.$href; # scheme missing
	} else if (substr($href, 0, 1) === "/") { 
		$href = $scheme.'://'.$host . $href; # scheme and domain missing
	} else if (substr($href, 0, 3) === '../' && !is_null($purl) && !empty($purl)) {
		$href = $scheme.':'.$host . dirname($path) . '/' . $href;
	} else if ($scheme == 'https' && substr($href, 0, 4) == 'http' && substr($href, 0, 5) !== $scheme) {
		$href = str_replace('http://', 'https://', $href); # force https
	} else {
		# url should be fine
	}

	# prevent double forward slashes in the middle
	$href = str_replace('###', '://', str_replace('//', '/', str_replace('://', '###', $href)));

	return $href;	
}

/** Get domain funvtion **/
function wpc_get_domain() {
	if (function_exists('site_url')) {
		$parse = parse_url(site_url());
		return $parse['host'];
	} elseif(isset($_SERVER['SERVER_NAME']) && !empty($_SERVER['SERVER_NAME'])) {
		return $_SERVER['SERVER_NAME'];
	} elseif (isset($_SERVER['HTTP_HOST']) && !empty($_SERVER['HTTP_HOST'])) {
		return $_SERVER['HTTP_HOST'];
	} else {
		return false;
	}
}

/** get css code from css file **/
function wpc_get_css_from_file($tag) {
	
	# globals
	
	# variables
	$tvers = get_option('wpc_last_cache_update', '0');
	
	# make sure we have a complete url
	$href = wpc_normalize_url($tag->href);
	
	# download, minify, cache (no ver query string)
	$tkey = wpc_generate_hash_with_prefix($href, 'css');
	$css = wpc_get_transient($tkey);
	
	if ($css === false) {
		
		$ddl = array();
		$ddl = wpc_maybe_download($href);
		
		# error
		if(isset($ddl['error'])) {
			return array('error'=>$ddl['error'], 'tkey'=>$tkey, 'url'=> $href);
		}
		
		# success
		if(isset($ddl['content'])) {
			
			# minify flag
			$min = true; 
							
			# minify
			$css = wpc_maybe_minify_css_file($ddl['content'], $href, $min);
			
			# quick integrity check
			if($css !== false) {

				# handle import rules
				$css = wpc_replace_css_imports($css, $href);
				$meta = json_encode(array('href'=>$href));
														
				# save transient
				$verify = wpc_set_transient(array('uid'=>$tkey, 'date'=>$tvers, 'type'=>'css', 'content'=>$css, 'meta'=>$meta));
								
				# success, from download
				return array('code'=>$css, 'tkey'=>$tkey, 'url'=> $href);
			}
		}
	
	} else {
		# success, from transient
		return array('code'=>$css, 'tkey'=>$tkey, 'url'=> $href);
	}
	return array('code'=>$css, 'tkey'=>$tkey, 'url'=> $href);			
}

# generate a 64 char string with prefix
function wpc_generate_hash_with_prefix($uid, $prefix) {
	return substr($prefix .hash('sha256', $uid), 0, 64);
}

/** Get transients **/
function wpc_get_transient($key) {
	
	# must have
	global $wpdb;
	if(is_null($wpdb)) { return false; }
	$db_prefix = $wpdb->prefix;
		
	try {
			
	} catch (Exception $e) {
		error_log('Error: '.$e->getMessage(), 0);
		return false;
	}
	
	# fallback
	return false;
}

/** Try to open the file from the disk, before downloading. **/
function wpc_maybe_download($url) {
	
	# must have
	if(is_null($url) || empty($url)) { return false; }
	
	# get domain
	$wpc_urls = array('wp_site_url'=>trailingslashit(site_url()), 'wp_domain'=>wpc_get_domain());	
	
	# check if we can open the file locally first
	if (stripos($url, $wpc_urls['wp_domain']) !== false && defined('ABSPATH') && !empty('ABSPATH')) {
		
		# file path + windows compatibility
		$f =  strtok(str_replace('/', DIRECTORY_SEPARATOR, str_replace(rtrim($wpc_urls['wp_site_url'], '/'), rtrim(ABSPATH, '/'), $url)), '?');
					
		# did it work?
		if (file_exists($f) && is_file($f)) {
			return array('content'=>file_get_contents($f), 'src'=>'Disk');
		}
	}
	
	# this useragent is needed for google fonts (woff files only + hinted fonts)
	$uagent = 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/46.0.2486.0 Safari/537.36 Edge/13.10586';

	# fetch via wordpress functions
	$response = wp_remote_get($url, array('user-agent'=>$uagent, 'timeout' => 7, 'httpversion' => '1.1', 'sslverify'=>false)); 
	if ( is_wp_error( $response ) ) {
		$error_message = $response->get_error_message();
		return array('error'=>"Something went wrong: $error_message");
	} else {
		return array('content'=>wp_remote_retrieve_body($response), 'src'=>'Web');
	}
}

/** Save minified code, if not yet available. **/
function wpc_generate_min_url($url, $tkey, $type, $code) {
		
	# cache date
	//$tvers = 1;
	$tvers = get_option('fvm_last_cache_update', '0');
		
	# parse uripath and check if it matches against our rewrite format
	$filename = $tvers.'-'.$tkey .'.'. $type;
	
	# check cache directory
	$ch_info = wpc_get_cache_location();
	if(isset($ch_info['ch_url'])  && !empty($ch_info['ch_url']) && isset($ch_info['ch_dir']) && !empty($ch_info['ch_dir'])) {
		if(is_dir($ch_info['ch_dir']) && is_writable($ch_info['ch_dir'])) {
			
			# filename
			$file = $ch_info['ch_dir'] . DIRECTORY_SEPARATOR . $filename;
			$public = $ch_info['ch_url'] . '/' .$filename;
			
			# enforce https on https requests
			if(parse_url($public, PHP_URL_SCHEME) != wpc_get_scheme()) {
				$public = str_replace('http://', 'https://', $public);
			}
			
			# php
			if(!file_exists($file) || (file_exists($file) && filemtime($file) < $tvers)) { file_put_contents($file, $code); }
			if(file_exists($file)) { return $public;
			 }
			
		}
	}
	
	# default, fail and log
	return false;
}

/** get cache location **/
function wpc_get_cache_location() {
	
	# custom path
	if (defined('WPC_CACHE_DIR') && defined('WPC_CACHE_URL')){
		
		# define paths and url
		$sep = DIRECTORY_SEPARATOR;
		$dir = trim(rtrim(WPC_CACHE_DIR, '/\\')). $sep . 'cache' . $sep . 'wpc'. $sep . 'min';
		$durl = trim(rtrim(WPC_CACHE_URL, '/')). '/cache/wpc/min';
		
		# create and return
		if(!is_dir($dir) && function_exists('wp_mkdir_p')) { wp_mkdir_p($dir); }
		return array('ch_dir'=>$dir,'ch_url'=>$durl);
		
	}
	
	
	# /wp-content/cache
	if (defined('WP_CONTENT_DIR') && defined('WP_CONTENT_URL')){
		
		# define paths and url
		$sep = DIRECTORY_SEPARATOR;
		$dir = trim(rtrim(WP_CONTENT_DIR, '/\\')). $sep . 'cache' . $sep . 'wpc'. $sep . 'min';
		$durl = trim(rtrim(WP_CONTENT_URL, '/')). '/cache/wpc/min';
		
		# create and return
		if(!is_dir($dir) && function_exists('wp_mkdir_p')) { wp_mkdir_p($dir); }

		return array('ch_dir'=>$dir,'ch_url'=>$durl);
		
	}	
	
	# uploads directory
	$ch_info = wp_upload_dir();
	if(isset($ch_info['basedir']) && isset($ch_info['baseurl']) && !empty($ch_info['basedir'])) {
	
		# define and create directory
		$sep = DIRECTORY_SEPARATOR;
		$dir = $ch_info['basedir'] . $sep . 'cache' . $sep . 'wpc'. $sep . 'min';
		$durl = $ch_info['baseurl'] . '/cache/wpc/min';
		
		# create and return
		if(!is_dir($dir) && function_exists('wp_mkdir_p')) { wp_mkdir_p($dir); }

		return array('ch_dir'=>$dir,'ch_url'=>$durl);
			
	}
	
	# error
	return false;

}

/** Replace css imports with origin css code **/
function wpc_replace_css_imports($css, $rq=null) {
	
	$wpc_urls = array('wp_site_url'=>trailingslashit(site_url()), 'wp_domain'=>wpc_get_domain());	
	
	# reset
	$cssimports = array();
	$cssimports_prepend = array();
	$css = trim($css);
	
	# cache version
	global $tvers;
	if(!is_numeric($tvers)) { 
		//$tvers = get_option('fvm_last_cache_update', '0'); 
	}

	if(isset($cssimports[0]) && isset($cssimports[2])) {
		foreach($cssimports[0] as $k=>$cssimport) {
				
			# if @import url rule, or guess full url
			if(stripos($cssimport, 'import url') !== false && isset($cssimports[2][$k])) {
				$url = trim($cssimports[2][$k]);
			} else {
				if(!is_null($rq) && !empty($rq)) {
					$url = dirname($rq) . '/' . trim($cssimports[2][$k]);	
				}
			}
			
			# must have
			if(!empty($url)) {
				
				# make sure we have a complete url
				$href = wpc_normalize_url($url);

				# download, minify, cache (no ver query string)
				$tkey = wpc_generate_hash_with_prefix($href, 'css');
				$subcss = wpc_get_transient($tkey);
				if ($subcss === false) {

					$enable_css_minification = true;			
					
					# force minification on google fonts
					if(stripos($href, 'fonts.googleapis.com') !== false) {
						$enable_css_minification = true;
					}
					
					# download file, get contents, merge
					$ddl = array();
					$ddl = wpc_maybe_download($href);
					
					# error
					if(isset($ddl['error'])) {
						return trim($css);
					}
				
					# if success
					if(isset($ddl['content'])) {
							
						# contents
						$subcss = $ddl['content'];
						
						# minify
						$subcss = wpc_maybe_minify_css_file($subcss, $href, $enable_css_minification);
		
						# trim code
						$subcss = trim($subcss);
								
						# save
						wpc_set_transient(array('uid'=>$tkey, 'date'=>$tvers, 'type'=>'css', 'content'=>$subcss));
					}
				}

				# remove import rule and prepend imported code
				if ($subcss !== false && !empty($subcss)) {
					$css = str_replace($cssimport, '', $css);
					$cssimports_prepend[] = '/* Import rule from: '.$href . ' */' . PHP_EOL . $subcss;
				}
				
			}
		}
	}# handle import url rules
	preg_match_all ("/@import[ ]*['\"]{0,}(url\()*['\"]*([^\(\{'\"\)]*)['\"\)]*[;]{0,}/ui", $css, $cssimports);
	
	
	# prepend import rules
	# https://www.w3.org/TR/CSS2/cascade.html#at-import
	if(count($cssimports_prepend) > 0) {
		$css = implode(PHP_EOL, $cssimports_prepend) . $css;
	}
	
	# return
	return trim($css);
	
}


/** validate and minify css **/
function wpc_maybe_minify_css_file($css, $url, $min) {
	
	# process css only if it's not php or html
	if(wpc_not_php_html($css)) {
		
		$wpc_urls = array('wp_site_url'=>trailingslashit(site_url()), 'wp_domain'=>wpc_get_domain());	
		
		# filtering
	
		$css = str_ireplace('@charset "UTF-8";', '', $css);
		
		# remove query strings from fonts
		$css = preg_replace('/(.eot|.woff2|.woff|.ttf)+[?+](.+?)(\)|\'|\")/ui', "$1"."$3", $css);

		# remove sourceMappingURL
		$css = preg_replace('/(\/\/\s*[#]\s*sourceMappingURL\s*[=]\s*)([a-zA-Z0-9-_\.\/]+)(\.map)/ui', '', $css);
		$css = preg_replace('/(\/[*]\s*[#]\s*sourceMappingURL\s*[=]\s*)([a-zA-Z0-9-_\.\/]+)(\.map)\s*[*]\s*[\/]/ui', '', $css);
		
		# fix url paths
		if(!empty($url)) {
			$matches = array(); preg_match_all("/url\(\s*['\"]?(?!data:)(?!http)(?![\/'\"])(.+?)['\"]?\s*\)/ui", $css, $matches);
			foreach($matches[1] as $a) { $b = trim($a); if($b != $a) { $css = str_replace($a, $b, $css); } }
			$css = preg_replace("/url\(\s*['\"]?(?!data:)(?!http)(?![\/'\"#])(.+?)['\"]?\s*\)/ui", "url(".dirname($url)."/$1)", $css);	
		}
		
		# minify string with relative urls
		if($min === true) {
			$css = wpc_minify_css_string($css, $url);
		}
		
		# add font-display block for all font faces
		# https://developers.google.com/web/updates/2016/02/font-display
		$css = preg_replace_callback('/(?:@font-face)\s*{(?<value>[^}]+)}/i',
			function ($matches) {
				if ( preg_match('/font-display:\s*(?<swap_value>\w*);?/i', $matches['value'], $attribute)) {
					return 'swap' === strtolower($attribute['swap_value']) ? $matches[0] : str_replace($attribute['swap_value'], 'swap', $matches[0]);
				} else {
					$swap = "font-display:swap;{$matches['value']}";
				}
				return str_replace( $matches['value'], $swap, $matches[0] );
			},
			$css
		);
		
		# make relative urls when possible
				
		# get root url, preserve subdirectories
		if(isset($wpc_urls['wp_site_url']) && !empty($wpc_urls['wp_site_url'])) {
			
			# parse url and extract domain without uri path
			$use_url = $wpc_urls['wp_site_url'];
			$parse = parse_url($use_url);
			if(isset($parse['path']) && !empty($parse['path']) && $parse['path'] != '/') {
				$use_url = str_replace(str_replace($use_url, $parse['path'], $use_url), '', $use_url);
			}
			
			# adjust paths
			$bgimgs = array();
			preg_match_all ('/url\s*\(\s*[\'\"]*([^;\'\"]*)[\'\"]*\)/Uui', $css, $bgimgs);
			if(isset($bgimgs[1]) && is_array($bgimgs[1])) {
				foreach($bgimgs[1] as $img) {
					if(stripos($img, 'http') !== false || stripos($img, '//') !== false) {
						
						# normalize
						$newimg = wpc_normalize_url($img);
						if($newimg != $img) { $css = str_replace($img, $newimg, $css); $img = $newimg; }
						
						# process
						if(substr($img, 0, strlen($use_url)) == $use_url) {
							$pos = strpos($img, $use_url);
							if ($pos !== false) {
								
								# relative path image
								$relimg = '/' . ltrim(substr_replace($img, '', $pos, strlen($use_url)), '/');
								
								# replace url
								$css = str_replace($img, $relimg, $css);
								
							}
						}
						
					}
				}
			}
			
			# remove empty url()
			$css = preg_replace('/url\s*\(\s*[\'"]?\s*[\'"]?\)/Uui', 'none', $css);
			
			# relative paths
			$css = str_replace('https://'.$wpc_urls['wp_domain'], '', $css);
			$css = str_replace('http://'.$wpc_urls['wp_domain'], '', $css);
			$css = str_replace('//'.$wpc_urls['wp_domain'], '', $css);
			
			# fixes
			$css = str_replace('/./', '/', $css);
			
		}
		
		# simplify font face
		// $arr = fvm_simplify_fontface($css);
		// if($arr !== false && is_array($arr)) {
		// 	$css = str_replace($arr['before'], $arr['after'], $css);
		// }
		
		# return css
		return trim($css);
	
	}

	return false;
}

/** Set cache **/
function wpc_set_transient($arr) {
	
	# must have
	if(!is_array($arr) || (is_array($arr) && (count($arr) == 0 || empty($arr)))) { return false; }
	if(!isset($arr['uid']) || !isset($arr['date']) || !isset($arr['type']) || !isset($arr['content'])) { return false; }
	
	# normalize unknown keys
	if(strlen($arr['uid']) != 64) { $arr['uid'] = wpc_generate_hash_with_prefix($arr['uid'], $arr['type']); }
	
	# check if it already exists, return early if it does
	$status = wpc_get_transient($arr['uid'], true);
	if($status) { return $arr['uid']; }	

	# must have
	global $wpdb;
	if(is_null($wpdb)) { return false; }
	$db_prefix = $wpdb->prefix;	
	
	# initialize arrays (fields, types, values)
	$fld = array();
	$tpe = array();
	$vls = array();
	
	# define possible data types
	$str = array('uid', 'type', 'content', 'meta');
	$int = array('date');
	$all = array_merge($str, $int);
	
	# process only recognized columns
	foreach($arr as $k=>$v) {
		if(in_array($k, $all)) {
			if(in_array($k, $str)) { $tpe[] = '%s'; } else { $tpe[] = '%d'; }
			$fld[] = $k;
			$vls[] = $v;
		}
	}
	
	try {
		# prepare and insert to database
		$result = $wpdb->query($wpdb->prepare("INSERT IGNORE INTO {$db_prefix}wpc_cache (".implode(', ', $fld).") VALUES (".implode(', ', $tpe).")", $vls));
		
		# success
		if($result) { 
			return $arr['uid']; 
		}
	} catch (Exception $e) {
		error_log('Error: '.$e->getMessage(), 0);
	}
		
	# fallback
	return false;
	
}

/** get the domain name **/
function wpc_get_scheme() {
	if(isset($_SERVER['HTTPS']) && strtolower($_SERVER['HTTPS']) === 'on') { return 'https'; }
	if(isset($_SERVER['HTTPS']) && '1' == $_SERVER['HTTPS']) { return 'https'; }
	if(isset($_SERVER['SERVER_PORT']) && $_SERVER['SERVER_PORT'] == 443) { return 'https'; }
	if(isset($_SERVER['HTTP_X_FORWARDED_PROTO']) && $_SERVER['HTTP_X_FORWARDED_PROTO'] == 'https') { return 'https'; }
	return 'http';
}

/** check for php or html, skip if found **/
function wpc_not_php_html($code) {
	
	# return early if not html
	$code = trim($code);
	$a = '<!doctype'; # start
	$b = '<html';     # start
	$c = '<?xml';     # start
	$d = '<?php';     # anywhere
		
	if ( strcasecmp(substr($code, 0, strlen($a)), $a) != 0 && strcasecmp(substr($code, 0, strlen($b)), $b) != 0 && strcasecmp(substr($code, 0, strlen($c)), $c) != 0 && stripos($code, $d) === false ) {
		return true;
	}
	
	return false;
}



# Error log.
function write_log ($log)  {
	if (true === WP_DEBUG) {
		if (is_array($log) || is_object($log)) {
			error_log(print_r($log, true));
		} else {
			error_log($log);
		}
	}
}









