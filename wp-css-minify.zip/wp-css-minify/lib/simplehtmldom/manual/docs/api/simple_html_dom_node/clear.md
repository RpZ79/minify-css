# clear

```php
clear ( )
```

Sets all properties in the current node, which contain objects, to null.