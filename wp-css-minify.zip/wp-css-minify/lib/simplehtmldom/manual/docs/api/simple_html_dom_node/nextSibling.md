# nextSibling

```php
nextSibling ( ) : object
```

This is a wrapper for [`next_sibling`](../next_sibling/).